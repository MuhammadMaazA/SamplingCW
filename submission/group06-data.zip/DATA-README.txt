Recorded data for the COMP0228 coursework 1 report

Unpack this zip inside the experiments folder of the code, so that it makes experiments/results.
The report scripts read the session folders from there.

What is in each session folder
Each folder is one recording session. It has plan.json (the trials we sent), capture.csv
(the timestamped brightness values from laptop 2), results.csv (one row per trial after
decoding), summary.csv, session.json (the settings) and the capture and session logs.
A few folders also hold a corrected or re-analysed results file, named in the list below.

The groups G01 to G29 in the report come from these folders
G01 to G07   normal light, 3 bps    monitor-room-comparison-20261030-180441-714350Z (results-t114.csv)
G08 to G14   normal light, 8 bps    final-comparison-20261031-150350-900428Z
G15 to G21   normal light, 4 bps    full1b-lab-comparison-20261027-174408-573804Z (results-corrected.csv)
G22 to G26   dim with glare, 4 bps  quiet1, quiet1b, quiet1c, quiet1d and quiet1e (one folder each)
G27          dim with glare, 2 bps  quiet2bps-lab-repetition-3-20261026-172410-806159Z
G28          normal light, 4 bps    quick-lab-repetition-3-20261027-173212-078354Z (repetition 3 check)
G29          normal light, 4 bps    test-lab-repetition-3-20261027-163916-214973Z (repetition 3 check)

Folders that are not in a group
monitor-room-comparison-20261030-180312-849922Z   stopped early, nothing usable
full1-laboutside-comparison-20261027-170708-296161Z   a different place at 2 bps, only 3 of 21 trials were filmed
glare-layouts-room-comparison-20261106-021921-294106Z   the 72 trial layout test, used in the layout test section of the report
the other two glare-layouts folders   two short earlier attempts at the same plan with almost no recording, not used in the report
report-final   the summary of all analysed groups that the report tables are built from
plans   the plan files that were made for the sessions

The notes saved inside some session.json files use early labels such as direct screen, mirror or reflection. They describe the same chain and were only working names.
Every session used the same chain. Laptop 1 flashes a black and white patch in front of an
iPad whose front camera shows it live, and the webcam of laptop 2 films the iPad screen.

Rebuilding the report from this data
1. Unpack the code zip, then unpack this zip inside its experiments folder.
2. python -m pip install -e ".[analysis]"
3. python report/make_figures.py
4. python report/gen_allruns.py
5. cd report, then latexmk -pdf report.tex
